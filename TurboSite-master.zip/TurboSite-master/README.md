# baronbot.github.io
Website for Baron, a League of Legends Discord bot.
